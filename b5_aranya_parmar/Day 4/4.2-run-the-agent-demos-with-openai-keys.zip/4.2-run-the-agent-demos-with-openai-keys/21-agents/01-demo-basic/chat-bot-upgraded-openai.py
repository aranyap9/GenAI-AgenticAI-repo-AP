# Use OpenAI
from openai import OpenAI
from agent_tools import agent_router

# ---------------- OPENAI API KEY ---------------- #

openai_path = r"C:\Users\DELL\Desktop\ai-upskill-5\share\ey-ai-upskill-b4-11052026-main\key-vault\openai\api.key"

with open(openai_path, "r") as f:
    api_key = f.read().strip()

# ---------------- INITIALIZE OPENAI CLIENT ---------------- #

client = OpenAI(api_key=api_key)

print("OpenAI client initialized successfully!", client)

# ---------------- SELECT MODEL ---------------- #

MODEL = "gpt-4o-mini"


# VIBE CODED USING GITHUB COPILOT

def chat():

    # Welcome message
    print("Welcome to the OpenAI Chat Bot! Type 'exit' to quit.")

    # Create messages queue
    messages = [
        {
            "role": "system",
            "content": "You are a helpful assistant."
        }
    ]

    # Chat loop
    while True:

        # User input
        user_input = input("You: ")

        # Exit condition
        if user_input.lower() in ["exit", "quit"]:
            print("Exiting the chat. Goodbye!")
            break

        # Add user message
        messages.append({
            "role": "user",
            "content": user_input
        })

        # ---------------- TOOLS LAYER ---------------- #

        agent_response = agent_router(user_input)

        if agent_response:

            print(f"[Agent Output]: {agent_response}")

            messages.append({
                "role": "system",
                "content": f"{agent_response}"
            })

        # ------------------------------------------------ #

        try:

            # Invoke OpenAI LLM
            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                temperature=0.7,
                max_tokens=100
            )

            # Extract response
            ai_reply = response.choices[0].message.content

            # Update messages
            messages.append({
                "role": "assistant",
                "content": ai_reply
            })

            # Print response
            print(f"Chatbot: {ai_reply}")

        except Exception as e:

            print("An error occurred while generating the response.")
            print(e)


# DEVELOPED FROM SCRATCH WITHOUT COPILOT

def chat2():

    # Welcome message
    print("Welcome to the chatbot! Type 'exit' to end the chat.\n")

    print("Chatbot: Hello! How can I assist you today?")

    # Create messages queue
    messages = [
        {
            "role": "system",
            "content": "You are a helpful assistant with a respectful tone"
        }
    ]

    # Chat loop
    while True:

        # User input
        user_input = input("You: ")

        # Exit condition
        if user_input.lower() in ["exit", "quit"]:

            print("Exiting the chat. Goodbye!")

            break

        # Add user input
        messages.append({
            "role": "user",
            "content": user_input
        })

        try:

            # Invoke OpenAI model
            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                temperature=0.7,
                max_tokens=100
            )

            # Extract AI reply
            ai_reply = response.choices[0].message.content

            # Update messages
            messages.append({
                "role": "assistant",
                "content": ai_reply
            })

            # Output reply
            print(f"Chatbot: {ai_reply}")

        except Exception as e:

            print("An error occurred.")
            print(e)


# LAUNCH CHATBOT

if __name__ == "__main__":

    chat()