# main.py

from openai import OpenAI
from agent_tools import handle_tool_call

# ----------------------------
# INITIALIZE OPENAI CLIENT
# ----------------------------

# Read the key from the file
with open(r"C:\Users\DELL\Desktop\ai-upskill-5\share\ey-ai-upskill-b4-11052026-main\key-vault\openai\api.key", "r") as f:
    api_key = f.read().strip()

# Initialize OpenAI client
client = OpenAI(api_key=api_key)

# Select model
MODEL = "gpt-4o-mini"


# ----------------------------
# CHAT FUNCTION
# ----------------------------
def chat():

    print("Welcome to the ChatBot! Type 'exit' or 'quit' to end the chat.\n")

    print("ChatBot: Hello! How can I assist you today?")

    messages = [
        {
            "role": "system",
            "content": "You are a helpful assistant."
        }
    ]

    while True:

        # ----------------------------
        # USER INPUT
        # ----------------------------
        user_input = input("\nYou: ")

        if user_input.lower() in ["exit", "quit"]:

            print("Exiting the chat. Goodbye!")

            break

        messages.append({
            "role": "user",
            "content": user_input
        })

        # ----------------------------
        # REACT LOOP
        # ----------------------------

        react_messages = messages.copy()

        # ----------------------------
        # REACT SYSTEM PROMPT
        # ----------------------------

        react_messages.append({
            "role": "system",
            "content": """
You are a ReAct style AI assistant.

Follow STRICTLY:

Thought: Reasoning
Action: one of [get_time, get_date, get_day, get_weather]
Action Input: input or NONE
Observation: tool result
Final Answer: final answer to the user

Rules:
- Use tools when needed
- For weather pass city name as input
- If no tool is needed, directly give the final answer
"""
        })

        final_answer = None

        reasoning_steps = []

        # ----------------------------
        # REASONING LOOP
        # ----------------------------

        for step in range(4):

            try:

                # ----------------------------
                # LLM CALL
                # ----------------------------

                response = client.chat.completions.create(
                    model=MODEL,
                    messages=react_messages,
                    temperature=0
                )

                # ----------------------------
                # EXTRACT REPLY
                # ----------------------------

                reply = response.choices[0].message.content.strip()

                react_messages.append({
                    "role": "assistant",
                    "content": reply
                })

                reasoning_steps.append(reply)

                # ----------------------------
                # TOOL EXECUTION
                # ----------------------------

                observation = handle_tool_call(reply, step)

                if observation:

                    react_messages.append({
                        "role": "user",
                        "content": observation
                    })

                    continue

                # ----------------------------
                # FINAL ANSWER CHECK
                # ----------------------------

                if "Final Answer:" in reply:

                    final_answer = reply.split(
                        "Final Answer:"
                    )[-1].strip()

                    break

            except Exception as e:

                print(f"Error during LLM call: {e}")

                break

        # ----------------------------
        # PRINT REASONING
        # ----------------------------

        print("\n--- ReAct Reasoning ---")

        for i, step_text in enumerate(reasoning_steps, 1):

            print(f"\nStep {i}:\n{step_text}")

        # ----------------------------
        # PRINT FINAL ANSWER
        # ----------------------------

        if final_answer:

            print(f"\nChatBot: {final_answer}")

            messages.append({
                "role": "assistant",
                "content": final_answer
            })

        else:

            print(
                "\nChatBot: Sorry, I couldn't complete the reasoning."
            )


# ----------------------------
# RUN APPLICATION
# ----------------------------

if __name__ == "__main__":

    chat()