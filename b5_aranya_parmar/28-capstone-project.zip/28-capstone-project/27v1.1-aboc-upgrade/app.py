"""
Final entry point for ABOC system
"""

import sys
import os

# -----------------------------
# Load OpenAI API Key from file
# -----------------------------

key_path = r"C:\Users\DELL\Desktop\ai-upskill-5\share\ey-ai-upskill-b4-11052026-main\key-vault\openai\api.key"

with open(key_path, "r") as f:
    api_key = f.read().strip()

# Set OpenAI API Key
os.environ["OPENAI_API_KEY"] = api_key

# Fix import issues
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from graph.workflow import build_workflow
from tools.database_tool import init_db


def main():

    print("\n🚀 ABOC AGENTIC SYSTEM (ADVANCED VERSION)\n")

    # Initialize DB
    init_db()

    # Build workflow
    app = build_workflow()

    while True:

        user_input = input("\nEnter your request (or 'exit'): ")

        if user_input.lower() == "exit":
            break

        result = app.invoke({
            "user_input": user_input
        })

        print("\n" + "=" * 50)
        print("✅ FINAL RESULT")
        print("=" * 50)

        for key, value in result.items():
            print(f"{key}: {value}")


if __name__ == "__main__":
    main()