"""
Predefined demo scenarios
"""

SCENARIOS = [
    "Create a PO for 50 sensors from VendorA under 400000 INR",
    "Create a PO for 100 devices from VendorX under 700000 INR"
]